import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import AboutSection from "@/components/AboutSection";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Index = () => (
  <div className="min-h-screen">
    <HeroSection />
    <ServicesSection />
    <AboutSection />
    <Footer />
    <WhatsAppButton />
  </div>
);

export default Index;

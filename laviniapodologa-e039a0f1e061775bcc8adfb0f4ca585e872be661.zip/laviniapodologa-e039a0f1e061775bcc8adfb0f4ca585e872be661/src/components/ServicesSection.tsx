import { Sparkles, Heart, Shield } from "lucide-react";

const services = [
  {
    icon: Sparkles,
    title: "Podologia Clínica",
    description: "Tratamento especializado para unhas encravadas, calos, calosidades e fissuras.",
  },
  {
    icon: Heart,
    title: "Cuidado Preventivo",
    description: "Avaliação completa dos pés para prevenir problemas e manter a saúde podológica.",
  },
  {
    icon: Shield,
    title: "Pé Diabético",
    description: "Atenção especializada para pacientes diabéticos com protocolos de segurança.",
  },
];

const ServicesSection = () => (
  <section className="py-20 px-6 bg-card">
    <div className="max-w-4xl mx-auto text-center">
      <p className="text-primary text-sm tracking-[0.2em] uppercase mb-2">Serviços</p>
      <h2 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-12">
        O que posso fazer por você
      </h2>

      <div className="grid md:grid-cols-3 gap-8">
        {services.map((s) => (
          <div
            key={s.title}
            className="group p-8 rounded-2xl bg-background border border-border hover:border-primary/30 hover:shadow-lg transition-all duration-300"
          >
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5 group-hover:bg-primary/20 transition-colors">
              <s.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-display text-xl font-semibold text-foreground mb-3">{s.title}</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">{s.description}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesSection;

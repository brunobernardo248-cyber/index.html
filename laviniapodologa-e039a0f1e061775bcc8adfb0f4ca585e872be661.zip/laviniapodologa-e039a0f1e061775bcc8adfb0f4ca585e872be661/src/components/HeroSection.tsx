import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => (
  <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
    <img
      src={heroBg}
      alt="Ambiente de spa com pétalas de rosa e velas"
      className="absolute inset-0 w-full h-full object-cover"
      width={1920}
      height={1080}
    />
    <div className="absolute inset-0 bg-gradient-to-b from-foreground/60 via-foreground/40 to-foreground/70" />

    <div className="relative z-10 text-center px-6 max-w-2xl">
      <p className="text-primary-foreground/80 text-sm tracking-[0.3em] uppercase mb-4 animate-fade-up">
        Cuidado & Bem-estar
      </p>
      <h1 className="font-display text-4xl md:text-6xl font-bold text-primary-foreground leading-tight animate-fade-up-delay">
        Lavínia Podóloga
      </h1>
      <div className="w-16 h-[2px] bg-accent mx-auto my-6 animate-fade-up-delay" />
      <p className="text-primary-foreground/90 text-lg md:text-xl font-light animate-fade-up-delay-2">
        Seus pés merecem atenção especial. Agende sua consulta e sinta a diferença de um cuidado profissional.
      </p>
    </div>
  </section>
);

export default HeroSection;

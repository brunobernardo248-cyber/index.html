import { MessageCircle } from "lucide-react";

const WHATSAPP_URL =
  "https://wa.me/5532998016614?text=Ola!%20Vim%20pelo%20seu%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.%20Voce%20pode%20me%20informar%20os%20horarios%20disponiveis?";

const WhatsAppButton = () => (
  <div className="fixed bottom-5 left-0 right-0 z-50 flex justify-center pointer-events-none">
    <a
      href={WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      className="pointer-events-auto flex items-center gap-2 px-8 py-4 bg-whatsapp text-primary-foreground font-semibold text-base rounded-full shadow-lg hover:bg-whatsapp-hover hover:scale-105 transition-all duration-300 animate-pulse-soft"
    >
      <MessageCircle className="w-5 h-5" />
      Falar no WhatsApp
    </a>
  </div>
);

export default WhatsAppButton;
